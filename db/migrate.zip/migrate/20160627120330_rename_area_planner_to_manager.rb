class RenameAreaPlannerToManager < ActiveRecord::Migration
  def change
    rename_table :area_planners, :managers
  end
end
