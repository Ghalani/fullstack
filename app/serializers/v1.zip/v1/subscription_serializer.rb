class SubscriptionSerializer < ActiveModel::Serializer
  attributes :id, :email
end
