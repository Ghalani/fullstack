class SaleSerializer < ActiveModel::Serializer
  attributes :id, :orgranization_id, :revenue
end
