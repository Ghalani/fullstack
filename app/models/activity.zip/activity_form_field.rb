class ActivityFormField < ActiveRecord::Base
  belongs_to :activity_form
end
